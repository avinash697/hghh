module.exports = {
  //mongoURI: "mongodb://spectre:spectre007@ds253537.mlab.com:53537/elearning", //apurva's
  mongoURI: 'mongodb+srv://admin:admin@cluster0-xb8vd.gcp.mongodb.net/E-learning?retryWrites=true&w=majority',
  secretOrKey: "a290u53n25039454545742tm40954245284452+5425426*42+5*"
};
